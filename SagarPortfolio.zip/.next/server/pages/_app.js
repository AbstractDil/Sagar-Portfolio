(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6375:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
var router_default = /*#__PURE__*/__webpack_require__.n(router_namespaceObject);
;// CONCATENATED MODULE: external "nprogress"
const external_nprogress_namespaceObject = require("nprogress");
var external_nprogress_default = /*#__PURE__*/__webpack_require__.n(external_nprogress_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: external "next-seo"
const external_next_seo_namespaceObject = require("next-seo");
;// CONCATENATED MODULE: ./pages/_app.js







router_default().events.on("routeChangeStart", (external_nprogress_default()).start);
router_default().events.on("routeChangeError", (external_nprogress_default()).done);
router_default().events.on("routeChangeComplete", (external_nprogress_default()).done);
//() => {
// console.log("route change");
//}
function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_seo_namespaceObject.NextSeo, {
                title: "Sagar Nandy | Junior Web Developer - https://nandysagar.in/ ",
                description: "Sagar Nandy - A junior web developer, who loves to design and develop beautiful web application.",
                canonical: "https://nandysagar.in/",
                openGraph: {
                    url: "https://nandysagar.in/",
                    title: "Sagar Nandy | A Junior Web Developer - https://nandysagar.in/ ",
                    description: "A junior web developer, who loves to design and develop beautiful web application.",
                    images: [
                        {
                            url: "Images/sg6.png",
                            width: 800,
                            height: 600,
                            alt: "Sagar Nandy - https://nandysagar.in/ ",
                            type: "image/jpeg/png"
                        }, 
                    ],
                    site_name: "Personal Portfolio website of Sagar Nandy - https://nandysagar.in/ "
                },
                twitter: {
                    handle: "@SagarNandy7",
                    site: "@SagarNandy7",
                    cardType: "summary_large_image"
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "lazyOnload",
                async: true,
                src: `https://www.googletagmanager.com/gtag/js?id=G-85ZR9XPNTG1`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "lazyOnload",
                children: `
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());
 
   gtag('config', 'G-85ZR9XPNTG');
   `
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "lazyOnload",
                src: "https://unpkg.com/sweetalert/dist/sweetalert.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "lazyOnload",
                children: `
document.addEventListener("contextmenu", function(event){
    event.preventDefault();
    swal("Right Click is Disabled By Administrator.","","warning");    
    }, false);


    document.onkeydown = function (e) {
  
        // disable F12 key
        if(e.keyCode == 123) 
        {
            swal(" F12 Key is Disabled By Administrator.","","warning"); 
            return false;
        }
 
        // disable I key
        if(e.ctrlKey && e.shiftKey && e.keyCode == 73){
            swal(" CTRL+SHIFT+I Key is Disabled By Administrator.","","warning"); 
            return false;
        }
 
        // disable J key
        if(e.ctrlKey && e.shiftKey && e.keyCode == 74) {
            swal(" CTRL+SHIFT+J Key is Disabled By Administrator.","","warning"); 
            return false;
        }
 
        // disable U key
        if(e.ctrlKey && e.keyCode == 85) {
            swal(" CTRL+U Key is Disabled By Administrator.","","warning"); 
            return false;
        }
        // disable F3 key
        if(e.ctrlKey  && e.shiftKey && e.keyCode == 114) {
            swal(" F3 Key is Disabled By Administrator.","","warning"); 
            return false;
        } 
        // disable R key
        if(e.ctrlKey  && e.shiftKey && e.keyCode == 82) {
            swal(" CTRL+SHIFT+R Key is Disabled By Administrator.","","warning"); 
            return false;
        }
        if(e.ctrlKey && e.keyCode == 82) {
            swal(" CTRL+R Key is Disabled By Administrator.","","warning"); 
            return false;
        }
        //f5 disable
        if(e.keyCode == 116) {
            swal(" F5 Key is Disabled By Administrator.","","warning"); 
            return false;
        }
        //A disable 
        if(e.ctrlKey && e.keyCode == 65) {
            swal(" CTRL+A Key is Disabled By Administrator.","","warning"); 
            return false;
        }

        // Copy disable 
        if(e.ctrlKey && e.keyCode == 67) {
            swal(" CTRL+C Key is Disabled By Administrator.","","warning"); 
            return false;
        }
        
    }


`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(699)


/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [699], () => (__webpack_exec__(6375)));
module.exports = __webpack_exports__;

})();